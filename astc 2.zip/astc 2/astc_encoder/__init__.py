"""
ASTC Encoder/Decoder
A Python-based command-line tool for ASTC texture compression and decompression.
"""

__version__ = '0.1.0'
