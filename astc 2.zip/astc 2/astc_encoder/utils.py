"""
Utility functions for ASTC encoder/decoder
"""
import os
import logging
import numpy as np
from typing import List, Tuple, Dict, Set, Optional

# Constants
DEFAULT_BLOCK_SIZES = [
    # 2D block sizes
    '4x4', '5x4', '5x5', '6x5', '6x6', '8x5', '8x6', '8x8', '10x5', 
    '10x6', '10x8', '10x10', '12x10', '12x12',
    # 3D block sizes
    '3x3x3', '4x3x3', '4x4x3', '4x4x4', '5x4x4', '5x5x4', '5x5x5', '6x5x5', '6x6x5', '6x6x6'
]

def is_valid_block_size(block_size: str) -> bool:
    """
    Check if a block size string is valid
    
    Args:
        block_size: Block size string (e.g., '4x4', '6x6x5')
        
    Returns:
        bool: True if valid, False otherwise
    """
    return block_size in DEFAULT_BLOCK_SIZES

def parse_block_size(block_size: str) -> List[int]:
    """
    Parse a block size string into dimensions
    
    Args:
        block_size: Block size string (e.g., '4x4', '6x6x5')
        
    Returns:
        List[int]: Block dimensions [width, height, depth]
    """
    if not is_valid_block_size(block_size):
        raise ValueError(f"Invalid block size: {block_size}")
    
    return [int(x) for x in block_size.split('x')]

def get_block_dimensions(block_size: str) -> Tuple[int, int, int]:
    """
    Get block dimensions from block size string
    
    Args:
        block_size: Block size string (e.g., '4x4', '6x6x5')
        
    Returns:
        Tuple[int, int, int]: Block width, height, depth
    """
    dims = parse_block_size(block_size)
    
    if len(dims) == 2:
        return dims[0], dims[1], 1
    elif len(dims) == 3:
        return dims[0], dims[1], dims[2]
    else:
        raise ValueError(f"Invalid block size format: {block_size}")

def calculate_file_size(width: int, height: int, depth: int, block_dims: List[int]) -> int:
    """
    Calculate the expected file size for an ASTC texture
    
    Args:
        width: Image width in pixels
        height: Image height in pixels
        depth: Image depth in pixels (1 for 2D textures)
        block_dims: Block dimensions [width, height, depth]
        
    Returns:
        int: Estimated file size in bytes
    """
    # Calculate number of blocks
    blocks_x = (width + block_dims[0] - 1) // block_dims[0]
    blocks_y = (height + block_dims[1] - 1) // block_dims[1]
    
    if len(block_dims) > 2:
        blocks_z = (depth + block_dims[2] - 1) // block_dims[2]
    else:
        blocks_z = 1
    
    # Each block is 16 bytes (128 bits)
    block_size_bytes = 16
    
    # Calculate total size
    header_size = 16  # ASTC header is 16 bytes
    data_size = blocks_x * blocks_y * blocks_z * block_size_bytes
    
    return header_size + data_size

def calculate_bitrate(block_dims: List[int]) -> float:
    """
    Calculate the bitrate for a given block size
    
    Args:
        block_dims: Block dimensions [width, height, depth]
        
    Returns:
        float: Bitrate in bits per texel
    """
    # Each ASTC block is 128 bits
    bits_per_block = 128
    
    # Calculate texels per block
    if len(block_dims) > 2:
        texels_per_block = block_dims[0] * block_dims[1] * block_dims[2]
    else:
        texels_per_block = block_dims[0] * block_dims[1]
    
    # Calculate bitrate
    return bits_per_block / texels_per_block

def calculate_compression_ratio(original_size: int, compressed_size: int) -> float:
    """
    Calculate compression ratio
    
    Args:
        original_size: Size of original image in bytes
        compressed_size: Size of compressed image in bytes
        
    Returns:
        float: Compression ratio (original/compressed)
    """
    if compressed_size == 0:
        return 0
    
    return original_size / compressed_size

def format_bytes(size_bytes: int) -> str:
    """
    Format bytes into a human-readable string
    
    Args:
        size_bytes: Size in bytes
        
    Returns:
        str: Formatted string (e.g., "1.23 KB")
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.2f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
