#!/usr/bin/env python3
"""
Command-line interface for ASTC texture compression/decompression
"""
import sys
from astc_encoder.cli import main

if __name__ == "__main__":
    sys.exit(main())
