"""
Image quality metrics for evaluating ASTC compression
"""
import os
import logging
import tempfile
import numpy as np
from PIL import Image
from typing import Dict, Any, Optional

from .encoder import compress_image
from .decoder import decompress_image
from .utils import calculate_compression_ratio, calculate_bitrate, parse_block_size

def compute_psnr(original: np.ndarray, compressed: np.ndarray) -> float:
    """
    Compute Peak Signal-to-Noise Ratio
    
    Args:
        original: Original image data as numpy array
        compressed: Compressed image data as numpy array
        
    Returns:
        float: PSNR value in dB
    """
    if original.shape != compressed.shape:
        raise ValueError(f"Image dimensions don't match: {original.shape} vs {compressed.shape}")
    
    # Calculate MSE (Mean Squared Error)
    mse = np.mean((original.astype(np.float32) - compressed.astype(np.float32)) ** 2)
    
    if mse == 0:
        return float('inf')  # Perfect match
    
    # Maximum pixel value is 255 for 8-bit images
    max_pixel_value = 255.0
    
    # Calculate PSNR
    psnr = 20 * np.log10(max_pixel_value / np.sqrt(mse))
    
    return psnr

def compute_ssim(original: np.ndarray, compressed: np.ndarray) -> float:
    """
    Compute Structural Similarity Index (SSIM)
    
    Args:
        original: Original image data as numpy array
        compressed: Compressed image data as numpy array
        
    Returns:
        float: SSIM value (0-1)
    """
    try:
        from skimage.metrics import structural_similarity as ssim
        return ssim(original, compressed, 
                   data_range=255,
                   channel_axis=2,  # For RGBA images
                   multichannel=True)  # For backwards compatibility
    except ImportError:
        logging.warning("scikit-image not available, SSIM calculation skipped")
        return 0.0

def compute_metrics(
    input_path: str, 
    block_size: str,
    color_profile: str = 'srgb',
    quality: int = 75,
    output_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Compute quality metrics for an image after ASTC compression
    
    Args:
        input_path: Path to input image
        block_size: Block size for compression
        color_profile: Color profile
        quality: Compression quality
        output_path: Optional path to save decompressed image
        
    Returns:
        Dict[str, Any]: Metrics including PSNR, SSIM, compression ratio, etc.
    """
    logging.info(f"Computing quality metrics for {input_path} with {block_size} blocks")
    
    # Load original image
    orig_img = Image.open(input_path)
    if orig_img.mode != 'RGBA':
        orig_img = orig_img.convert('RGBA')
    
    orig_data = np.array(orig_img)
    original_size = os.path.getsize(input_path)
    
    # Create temporary files for compression/decompression
    with tempfile.NamedTemporaryFile(suffix='.astc') as temp_astc:
        # Compress the image
        compress_image(
            input_path, 
            temp_astc.name, 
            block_size, 
            color_profile, 
            quality
        )
        
        compressed_size = os.path.getsize(temp_astc.name)
        
        # Decompress for comparison
        if output_path:
            decomp_path = output_path
        else:
            with tempfile.NamedTemporaryFile(suffix='.png') as temp_decomp:
                decomp_path = temp_decomp.name
        
        decompress_image(temp_astc.name, decomp_path, color_profile)
        
        # Load decompressed image for comparison
        decomp_img = Image.open(decomp_path)
        decomp_data = np.array(decomp_img)
    
    # Calculate metrics
    psnr_value = compute_psnr(orig_data, decomp_data)
    
    # Calculate bitrate
    block_dims = parse_block_size(block_size)
    bitrate = calculate_bitrate(block_dims)
    
    # Calculate compression ratio
    compression_ratio = calculate_compression_ratio(original_size, compressed_size)
    
    metrics = {
        'psnr': psnr_value,
        'bitrate': bitrate,
        'compression_ratio': compression_ratio,
        'original_size': original_size,
        'compressed_size': compressed_size,
        'block_size': block_size
    }
    
    # Try to compute SSIM if scikit-image is available
    try:
        ssim_value = compute_ssim(orig_data, decomp_data)
        metrics['ssim'] = ssim_value
    except:
        logging.warning("Failed to compute SSIM")
    
    logging.info(f"PSNR: {psnr_value:.2f} dB, Compression ratio: {compression_ratio:.2f}x")
    
    return metrics
