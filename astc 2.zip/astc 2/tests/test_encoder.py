"""
Unit tests for ASTC encoder functions
"""
import os
import pytest
import tempfile
import numpy as np
from PIL import Image

from astc_encoder.encoder import compress_image
from astc_encoder.utils import parse_block_size, is_valid_block_size

# Create a simple test image
def create_test_image(width=64, height=64, mode='RGBA'):
    """Create a test image with a simple pattern"""
    img = Image.new(mode, (width, height), color=(0, 0, 0, 0))
    pixels = img.load()
    
    # Create a simple gradient pattern
    for y in range(height):
        for x in range(width):
            r = int(255 * x / width)
            g = int(255 * y / height)
            b = int(255 * (x + y) / (width + height))
            a = 255
            pixels[x, y] = (r, g, b, a)
    
    return img

def test_valid_block_sizes():
    """Test valid block size parsing"""
    # Test known valid block sizes
    assert is_valid_block_size('4x4') == True
    assert is_valid_block_size('6x6') == True
    assert is_valid_block_size('8x8') == True
    assert is_valid_block_size('5x5x5') == True
    
    # Test invalid block sizes
    assert is_valid_block_size('3x3') == False
    assert is_valid_block_size('7x7') == False
    assert is_valid_block_size('invalid') == False

def test_block_size_parsing():
    """Test block size parsing"""
    # Test 2D block sizes
    assert parse_block_size('4x4') == [4, 4]
    assert parse_block_size('6x5') == [6, 5]
    
    # Test 3D block sizes
    assert parse_block_size('5x5x5') == [5, 5, 5]
    assert parse_block_size('6x6x6') == [6, 6, 6]
    
    # Test invalid block size
    with pytest.raises(ValueError):
        parse_block_size('invalid')

def test_compression():
    """Test basic image compression"""
    # Create a test image
    test_img = create_test_image(64, 64)
    
    with tempfile.NamedTemporaryFile(suffix='.png') as temp_input:
        with tempfile.NamedTemporaryFile(suffix='.astc') as temp_output:
            # Save the test image
            test_img.save(temp_input.name)
            
            # Compress the image
            compress_image(
                temp_input.name,
                temp_output.name,
                block_size='4x4',
                color_profile='srgb'
            )
            
            # Check if the output file exists and has content
            assert os.path.exists(temp_output.name)
            assert os.path.getsize(temp_output.name) > 0

def test_compression_different_block_sizes():
    """Test compression with different block sizes"""
    # Create a test image
    test_img = create_test_image(64, 64)
    
    with tempfile.NamedTemporaryFile(suffix='.png') as temp_input:
        test_img.save(temp_input.name)
        
        # Test different block sizes
        block_sizes = ['4x4', '8x8', '12x12']
        output_sizes = []
        
        for block_size in block_sizes:
            with tempfile.NamedTemporaryFile(suffix='.astc') as temp_output:
                # Compress the image
                compress_image(
                    temp_input.name,
                    temp_output.name,
                    block_size=block_size,
                    color_profile='srgb'
                )
                
                # Record the output size
                output_sizes.append(os.path.getsize(temp_output.name))
        
        # Larger block sizes should result in smaller files
        assert output_sizes[0] > output_sizes[1] > output_sizes[2]

def test_3d_compression():
    """Test 3D texture compression (if supported)"""
    # Skip if matplotlib is not available for 3D array creation
    pytest.importorskip("matplotlib")
    
    # Create a simple 3D volume (requires numpy)
    volume_size = 32
    volume = np.zeros((volume_size, volume_size, volume_size, 4), dtype=np.uint8)
    
    # Fill with a simple pattern
    for z in range(volume_size):
        for y in range(volume_size):
            for x in range(volume_size):
                volume[y, x, z, 0] = int(255 * x / volume_size)  # R
                volume[y, x, z, 1] = int(255 * y / volume_size)  # G
                volume[y, x, z, 2] = int(255 * z / volume_size)  # B
                volume[y, x, z, 3] = 255  # A
    
    # Save as a series of 2D slices
    with tempfile.TemporaryDirectory() as temp_dir:
        # Save middle slice
        middle_slice = volume[:, :, volume_size // 2]
        slice_img = Image.fromarray(middle_slice)
        input_path = os.path.join(temp_dir, 'input.png')
        slice_img.save(input_path)
        
        # Compress
        output_path = os.path.join(temp_dir, 'output.astc')
        compress_image(
            input_path,
            output_path,
            block_size='4x4x4',
            color_profile='linear',
            dimension='3d'
        )
        
        # Check if the output file exists and has content
        assert os.path.exists(output_path)
        assert os.path.getsize(output_path) > 0
