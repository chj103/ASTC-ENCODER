"""
Setup script for ASTC Encoder
"""
import os
import sys
from setuptools import setup, find_packages, Extension

try:
    from Cython.Build import cythonize
    USE_CYTHON = True
except ImportError:
    USE_CYTHON = False

# Set compiler flags for optimizations
extra_compile_args = ['-O3']

# Add platform-specific flags for SSE4.2 support
if sys.platform == 'win32':
    extra_compile_args.extend(['/arch:SSE4.2'])
else:  # Unix-like (Linux, macOS)
    extra_compile_args.extend(['-msse4.2'])

# Define extensions
extensions = []
if USE_CYTHON:
    extensions = cythonize([
        Extension(
            "astc_encoder.optimizations",
            ["astc_encoder/optimizations.pyx"],
            extra_compile_args=extra_compile_args,
            include_dirs=[],  # Add numpy include here if needed
        )
    ])
else:
    print("WARNING: Cython not available, falling back to Python implementation")
    # No C extension in this case

setup(
    name="astc_encoder",
    version="0.1.0",
    description="ASTC texture compression tool",
    author="ASTC Encoder Team",
    packages=find_packages(),
    ext_modules=extensions,
    entry_points={
        'console_scripts': [
            'astc=astc_encoder.cli:main',
        ],
    },
    python_requires='>=3.9',
    install_requires=[
        'numpy',
        'pillow',
        'scipy',
        'opencv-python',
    ],
    extras_require={
        'quality': ['scikit-image'],
        'dev': ['cython'],
    },
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Developers',
        'Topic :: Multimedia :: Graphics',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
)
