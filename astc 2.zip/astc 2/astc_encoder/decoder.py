"""
ASTC Decoder module - handles decompression of ASTC files back to images
"""
import logging
import numpy as np
from PIL import Image
from typing import Tuple, Optional, List, Dict, Union

from .core import decompress_block, parse_astc_header
from .color_profiles import apply_color_profile

def decompress_image(
    input_path: str, 
    output_path: str, 
    color_profile: str = 'srgb'
) -> None:
    """
    Decompress an ASTC file to an image
    
    Args:
        input_path: Path to input ASTC file
        output_path: Path to output image file (PNG, BMP)
        color_profile: Color profile ('linear' or 'srgb')
    """
    # Read ASTC file
    logging.info(f"Loading ASTC file: {input_path}")
    with open(input_path, 'rb') as f:
        astc_data = f.read()
    
    # Parse header
    header_size, width, height, depth, block_dims = parse_astc_header(astc_data)
    logging.debug(f"ASTC header: {width}x{height}x{depth}, Block size: {block_dims}")
    
    # Check if this is a 3D texture
    is_3d = (depth > 1)
    if is_3d:
        logging.info(f"Processing 3D texture with {depth} slices")
    
    # Calculate block grid
    blocks_x = (width + block_dims[0] - 1) // block_dims[0]
    blocks_y = (height + block_dims[1] - 1) // block_dims[1]
    blocks_z = 1
    if is_3d:
        blocks_z = (depth + block_dims[2] - 1) // block_dims[2]
    
    total_blocks = blocks_x * blocks_y * blocks_z
    logging.info(f"Decompressing {total_blocks} blocks ({blocks_x}x{blocks_y}x{blocks_z})")
    
    # Create output image array
    if is_3d:
        decompressed_data = np.zeros((height, width, depth, 4), dtype=np.uint8)
    else:
        decompressed_data = np.zeros((height, width, 4), dtype=np.uint8)
    
    # Process each block
    block_data_size = 16  # ASTC blocks are always 128 bits (16 bytes)
    block_count = 0
    
    for z in range(blocks_z):
        for y in range(blocks_y):
            for x in range(blocks_x):
                # Calculate block position in file
                block_index = z * (blocks_x * blocks_y) + y * blocks_x + x
                block_offset = header_size + block_index * block_data_size
                
                if block_offset + block_data_size > len(astc_data):
                    logging.error(f"Block offset {block_offset} exceeds file size {len(astc_data)}")
                    break
                
                # Extract compressed block data
                block_compressed = astc_data[block_offset:block_offset + block_data_size]
                
                # Calculate pixel coordinates
                x_start = x * block_dims[0]
                y_start = y * block_dims[1]
                x_end = min(x_start + block_dims[0], width)
                y_end = min(y_start + block_dims[1], height)
                
                # Decompress the block
                if is_3d:
                    z_start = z * block_dims[2]
                    z_end = min(z_start + block_dims[2], depth)
                    
                    # Decompress 3D block
                    block_decompressed = decompress_block(block_compressed, block_dims)
                    
                    # Place in output array
                    for dz in range(z_end - z_start):
                        for dy in range(y_end - y_start):
                            for dx in range(x_end - x_start):
                                decompressed_data[y_start + dy, x_start + dx, z_start + dz] = block_decompressed[dy, dx, dz]
                else:
                    # Decompress 2D block
                    block_decompressed = decompress_block(block_compressed, block_dims)
                    
                    # Place in output array
                    decompressed_data[y_start:y_end, x_start:x_end] = block_decompressed[:y_end-y_start, :x_end-x_start]
                
                block_count += 1
                if block_count % 1000 == 0 or block_count == total_blocks:
                    logging.info(f"Decompressed {block_count}/{total_blocks} blocks ({block_count/total_blocks*100:.1f}%)")
    
    # Apply inverse color profile
    decompressed_data = apply_color_profile(decompressed_data, color_profile, direction='from_linear')
    
    # Ensure data is in the right format for PIL (uint8)
    if decompressed_data.dtype != np.uint8:
        logging.debug(f"Converting decompressed data from {decompressed_data.dtype} to uint8")
        decompressed_data = decompressed_data.astype(np.uint8)
    
    # Save output image
    if is_3d:
        # For 3D textures, save the middle slice or save all slices as separate files
        middle_slice = depth // 2
        img = Image.fromarray(decompressed_data[:, :, middle_slice], 'RGBA')
        img.save(output_path)
        logging.info(f"Saved middle slice ({middle_slice}) of 3D texture to {output_path}")
    else:
        img = Image.fromarray(decompressed_data, 'RGBA')
        img.save(output_path)
        logging.info(f"Decompressed image saved to {output_path}")
