"""
Unit tests for ASTC quality metrics
"""
import os
import pytest
import tempfile
import numpy as np
from PIL import Image

from astc_encoder.metrics import compute_psnr, compute_metrics
from astc_encoder.encoder import compress_image
from astc_encoder.decoder import decompress_image

# Create a simple test image
def create_test_image(width=64, height=64, mode='RGBA'):
    """Create a test image with a simple pattern"""
    img = Image.new(mode, (width, height), color=(0, 0, 0, 0))
    pixels = img.load()
    
    # Create a simple gradient pattern
    for y in range(height):
        for x in range(width):
            r = int(255 * x / width)
            g = int(255 * y / height)
            b = int(255 * (x + y) / (width + height))
            a = 255
            pixels[x, y] = (r, g, b, a)
    
    return img

def test_psnr_calculation():
    """Test PSNR calculation for identical images"""
    # Create two identical images
    img1 = create_test_image(32, 32)
    img2 = create_test_image(32, 32)
    
    # Convert to numpy arrays
    arr1 = np.array(img1)
    arr2 = np.array(img2)
    
    # PSNR of identical images should be infinity
    psnr = compute_psnr(arr1, arr2)
    assert psnr == float('inf')
    
    # Slightly modify one image
    arr2[16, 16] = [128, 128, 128, 255]  # Change one pixel
    
    # PSNR should now be finite
    psnr = compute_psnr(arr1, arr2)
    assert np.isfinite(psnr)
    assert psnr > 0

def test_quality_metrics():
    """Test computing quality metrics"""
    # Create a test image
    test_img = create_test_image(64, 64)
    
    with tempfile.NamedTemporaryFile(suffix='.png') as temp_input:
        # Save the test image
        test_img.save(temp_input.name)
        
        # Compute metrics
        metrics = compute_metrics(
            temp_input.name,
            block_size='4x4',
            color_profile='srgb'
        )
        
        # Check metrics
        assert 'psnr' in metrics
        assert 'compression_ratio' in metrics
        assert 'original_size' in metrics
        assert 'compressed_size' in metrics
        assert 'bitrate' in metrics
        
        # Check reasonable values
        assert metrics['original_size'] > 0
        assert metrics['compressed_size'] > 0
        assert metrics['compression_ratio'] > 0
        assert metrics['psnr'] > 0 or metrics['psnr'] == float('inf')

def test_block_size_impact():
    """Test the impact of block size on quality metrics"""
    # Create a test image
    test_img = create_test_image(64, 64)
    
    with tempfile.NamedTemporaryFile(suffix='.png') as temp_input:
        # Save the test image
        test_img.save(temp_input.name)
        
        # Test different block sizes
        block_sizes = ['4x4', '8x8']
        metrics_list = []
        
        for block_size in block_sizes:
            metrics = compute_metrics(
                temp_input.name,
                block_size=block_size,
                color_profile='srgb'
            )
            metrics_list.append(metrics)
        
        # Smaller blocks should give better quality (higher PSNR)
        if metrics_list[0]['psnr'] != float('inf') and metrics_list[1]['psnr'] != float('inf'):
            assert metrics_list[0]['psnr'] >= metrics_list[1]['psnr']
        
        # Smaller blocks should result in larger files (lower compression ratio)
        assert metrics_list[0]['compressed_size'] >= metrics_list[1]['compressed_size']

def test_metrics_with_output():
    """Test computing metrics with output decompressed image"""
    # Create a test image
    test_img = create_test_image(64, 64)
    
    with tempfile.NamedTemporaryFile(suffix='.png') as temp_input:
        with tempfile.NamedTemporaryFile(suffix='.png') as temp_output:
            # Save the test image
            test_img.save(temp_input.name)
            
            # Compute metrics and save output
            metrics = compute_metrics(
                temp_input.name,
                block_size='4x4',
                color_profile='srgb',
                output_path=temp_output.name
            )
            
            # Check if output file exists
            assert os.path.exists(temp_output.name)
            assert os.path.getsize(temp_output.name) > 0
            
            # Load and check the output image
            output_img = Image.open(temp_output.name)
            assert output_img.size == test_img.size
