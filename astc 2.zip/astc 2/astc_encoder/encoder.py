"""
ASTC Encoder module - handles compression of images to ASTC format
"""
import os
import logging
import numpy as np
from PIL import Image
from typing import Tuple, Optional, List, Dict, Union

from .core import compress_block, create_astc_header
from .utils import get_block_dimensions, parse_block_size
from .color_profiles import apply_color_profile

def compress_image(
    input_path: str, 
    output_path: str, 
    block_size: str = '4x4', 
    color_profile: str = 'srgb',
    quality: int = 75,
    dimension: str = '2d'
) -> None:
    """
    Compress an image file to ASTC format
    
    Args:
        input_path: Path to input image file (PNG, BMP)
        output_path: Path to output ASTC file
        block_size: Block size in format WxH or WxHxD (e.g. '4x4' or '5x5x5')
        color_profile: Color profile ('linear' or 'srgb')
        quality: Compression quality (0-100)
        dimension: Texture dimension ('2d' or '3d')
    """
    # Load and preprocess the image
    logging.info(f"Loading image: {input_path}")
    img = Image.open(input_path)
    
    # Convert to RGBA if not already
    if img.mode != 'RGBA':
        img = img.convert('RGBA')
    
    # Apply color profile
    img_data = np.array(img)
    processed_data = apply_color_profile(img_data, color_profile, direction='to_linear')
    
    # Get image dimensions
    width, height = img.size
    depth = 1  # Default for 2D textures
    
    # Parse block size
    block_dims = parse_block_size(block_size)
    if dimension == '3d' and len(block_dims) < 3:
        # For 3D textures, ensure we have a depth dimension
        block_dims.append(1)
    elif dimension == '2d' and len(block_dims) > 2:
        # For 2D textures, truncate to 2D block size
        block_dims = block_dims[:2]
    
    logging.debug(f"Image dimensions: {width}x{height}, Block size: {block_dims}")
    
    # Create ASTC header
    header = create_astc_header(width, height, depth, block_dims)
    
    # Calculate blocks
    blocks_x = (width + block_dims[0] - 1) // block_dims[0]
    blocks_y = (height + block_dims[1] - 1) // block_dims[1]
    blocks_z = 1
    if len(block_dims) > 2:
        blocks_z = (depth + block_dims[2] - 1) // block_dims[2]
    
    total_blocks = blocks_x * blocks_y * blocks_z
    logging.info(f"Compressing {total_blocks} blocks ({blocks_x}x{blocks_y}x{blocks_z})")
    
    # Compress all blocks
    compressed_data = bytearray()
    compressed_data.extend(header)
    
    # Quality factor affects encoding parameters
    error_threshold = 0.05 * (100 - quality) / 100  # Higher quality = lower error threshold
    
    # Process each block
    block_count = 0
    for z in range(blocks_z):
        for y in range(blocks_y):
            for x in range(blocks_x):
                # Extract block data
                x_start = x * block_dims[0]
                y_start = y * block_dims[1]
                x_end = min(x_start + block_dims[0], width)
                y_end = min(y_start + block_dims[1], height)
                
                # Get the block pixels
                if dimension == '2d':
                    block_data = processed_data[y_start:y_end, x_start:x_end]
                else:
                    z_start = z * block_dims[2]
                    z_end = min(z_start + block_dims[2], depth)
                    block_data = processed_data[y_start:y_end, x_start:x_end, z_start:z_end]
                
                # Pad block if needed
                if block_data.shape[0] < block_dims[1] or block_data.shape[1] < block_dims[0]:
                    padded_block = np.zeros((block_dims[1], block_dims[0], 4), dtype=np.uint8)
                    padded_block[:block_data.shape[0], :block_data.shape[1]] = block_data
                    block_data = padded_block
                
                # Compress the block
                block_compressed = compress_block(block_data, block_dims, error_threshold)
                compressed_data.extend(block_compressed)
                
                block_count += 1
                if block_count % 1000 == 0 or block_count == total_blocks:
                    logging.info(f"Compressed {block_count}/{total_blocks} blocks ({block_count/total_blocks*100:.1f}%)")
    
    # Write compressed data to output file
    with open(output_path, 'wb') as f:
        f.write(compressed_data)
    
    file_size = os.path.getsize(output_path)
    logging.info(f"Compressed file written to {output_path} ({file_size/1024:.1f} KB)")
