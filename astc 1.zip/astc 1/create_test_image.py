#!/usr/bin/env python3
"""
Creates a simple test image for ASTC compression testing
"""

import numpy as np
from PIL import Image
import os

def create_gradient_image(filename="test_gradient.png", size=(256, 256)):
    """Create a simple RGB gradient test image"""
    # Create a gradient image
    image = np.zeros((size[1], size[0], 3), dtype=np.uint8)
    
    # Fill with a gradient
    for y in range(size[1]):
        for x in range(size[0]):
            r = int(255 * x / size[0])
            g = int(255 * y / size[1])
            b = int(255 * (x + y) / (size[0] + size[1]))
            image[y, x] = [r, g, b]
    
    # Convert to RGBA (add alpha channel)
    rgba = np.zeros((size[1], size[0], 4), dtype=np.uint8)
    rgba[:, :, :3] = image
    rgba[:, :, 3] = 255  # Full opacity
    
    # Save the image
    img = Image.fromarray(rgba, 'RGBA')
    img.save(filename)
    print(f"Created test image: {filename}")
    return filename

def create_pattern_image(filename="test_pattern.png", size=(256, 256)):
    """Create a test image with geometric patterns"""
    # Create a blank image
    image = np.zeros((size[1], size[0], 4), dtype=np.uint8)
    
    # Add a checkboard pattern in the background
    block_size = 32
    for y in range(0, size[1], block_size):
        for x in range(0, size[0], block_size):
            if (x // block_size + y // block_size) % 2 == 0:
                image[y:y+block_size, x:x+block_size] = [200, 200, 200, 255]
            else:
                image[y:y+block_size, x:x+block_size] = [100, 100, 100, 255]
    
    # Add a colored circle
    center_x, center_y = size[0] // 2, size[1] // 2
    radius = min(size[0], size[1]) // 3
    
    for y in range(size[1]):
        for x in range(size[0]):
            dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            if dist < radius:
                image[y, x] = [255, 0, 0, 255]  # Red circle
    
    # Add some colored squares
    square_size = 40
    colors = [
        [0, 255, 0, 255],    # Green
        [0, 0, 255, 255],     # Blue
        [255, 255, 0, 255],   # Yellow
        [255, 0, 255, 255]    # Magenta
    ]
    
    positions = [
        (50, 50),
        (size[0] - 50 - square_size, 50),
        (50, size[1] - 50 - square_size),
        (size[0] - 50 - square_size, size[1] - 50 - square_size)
    ]
    
    for (x, y), color in zip(positions, colors):
        image[y:y+square_size, x:x+square_size] = color
    
    # Save the image
    img = Image.fromarray(image, 'RGBA')
    img.save(filename)
    print(f"Created test image: {filename}")
    return filename

def main():
    """Create test images"""
    create_gradient_image()
    create_pattern_image()
    
    print("\nTest images created. You can now use them with the ASTC encoder:")
    print("python astc.py compress test_gradient.png test_gradient.astc --block-size 4x4")
    print("python astc.py compress test_pattern.png test_pattern.astc --block-size 4x4")
    print("\nTo decompress back:")
    print("python astc.py decompress test_gradient.astc test_gradient_decompressed.png")
    print("python astc.py decompress test_pattern.astc test_pattern_decompressed.png")
    print("\nTo test compression quality:")
    print("python astc.py test test_gradient.png --block-size 4x4 --output test_gradient_result.png")

if __name__ == "__main__":
    main()
