"""
Color profile conversion utilities for ASTC encoder
"""
import numpy as np
import logging
from typing import Literal

def apply_color_profile(
    data: np.ndarray, 
    profile: str, 
    direction: Literal['to_linear', 'from_linear'] = 'to_linear'
) -> np.ndarray:
    """
    Apply color profile conversion to image data
    
    Args:
        data: Image data as numpy array
        profile: Color profile ('linear' or 'srgb')
        direction: Direction of conversion ('to_linear' or 'from_linear')
    
    Returns:
        np.ndarray: Converted image data
    """
    if profile == 'linear':
        # Linear profile doesn't need conversion
        return data
    
    elif profile == 'srgb':
        if direction == 'to_linear':
            return srgb_to_linear(data)
        else:
            return linear_to_srgb(data)
    
    else:
        logging.warning(f"Unknown color profile: {profile}, using linear")
        return data

def srgb_to_linear(srgb_data: np.ndarray) -> np.ndarray:
    """
    Convert sRGB color values to linear color space
    
    Args:
        srgb_data: Image data in sRGB format
    
    Returns:
        np.ndarray: Image data in linear format
    """
    # Create a copy to avoid modifying the original
    linear_data = srgb_data.copy().astype(np.float32)
    
    # Normalize to 0-1 range
    rgb = linear_data[..., :3] / 255.0
    
    # Apply sRGB to linear conversion
    # For each RGB channel (not alpha)
    mask = rgb <= 0.04045
    rgb[mask] = rgb[mask] / 12.92
    rgb[~mask] = ((rgb[~mask] + 0.055) / 1.055) ** 2.4
    
    # Convert back to 0-255 range
    linear_data[..., :3] = np.clip(rgb * 255.0, 0, 255).astype(np.uint8)
    
    return linear_data

def linear_to_srgb(linear_data: np.ndarray) -> np.ndarray:
    """
    Convert linear color values to sRGB color space
    
    Args:
        linear_data: Image data in linear format
    
    Returns:
        np.ndarray: Image data in sRGB format
    """
    # Create a copy to avoid modifying the original
    srgb_data = linear_data.copy().astype(np.float32)
    
    # Normalize to 0-1 range
    rgb = srgb_data[..., :3] / 255.0
    
    # Apply linear to sRGB conversion
    # For each RGB channel (not alpha)
    mask = rgb <= 0.0031308
    rgb[mask] = rgb[mask] * 12.92
    rgb[~mask] = 1.055 * (rgb[~mask] ** (1 / 2.4)) - 0.055
    
    # Convert back to 0-255 range
    srgb_data[..., :3] = np.clip(rgb * 255.0, 0, 255).astype(np.uint8)
    
    return srgb_data
