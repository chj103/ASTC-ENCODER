"""
Command Line Interface for ASTC Encoder/Decoder
"""
import argparse
import os
import sys
import logging
from typing import List, Optional

from .encoder import compress_image
from .decoder import decompress_image
from .metrics import compute_psnr, compute_metrics
from .utils import is_valid_block_size, DEFAULT_BLOCK_SIZES

def setup_logging(verbosity: int) -> None:
    """Configure logging based on verbosity level"""
    log_level = logging.WARNING
    if verbosity == 1:
        log_level = logging.INFO
    elif verbosity >= 2:
        log_level = logging.DEBUG
    
    logging.basicConfig(
        level=log_level,
        format='%(levelname)s: %(message)s'
    )

def create_parser() -> argparse.ArgumentParser:
    """Create and return the command line argument parser"""
    parser = argparse.ArgumentParser(
        description='ASTC texture compression encoder/decoder',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Compress an image:
    python -m astc_encoder compress input.png output.astc --block-size 4x4

  Decompress an image:
    python -m astc_encoder decompress input.astc output.png

  Test compression quality:
    python -m astc_encoder test input.png --block-size 6x6
        """
    )
    
    parser.add_argument('-v', '--verbose', action='count', default=0,
                        help='Increase verbosity (can be used multiple times)')
    
    subparsers = parser.add_subparsers(dest='command', help='Command to execute')
    
    # Compress command
    compress_parser = subparsers.add_parser('compress', help='Compress an image to ASTC format')
    compress_parser.add_argument('input', help='Input image file (PNG, BMP)')
    compress_parser.add_argument('output', help='Output ASTC file')
    compress_parser.add_argument('--block-size', default='4x4', 
                                help=f'Block size for compression. Options: {", ".join(DEFAULT_BLOCK_SIZES)}')
    compress_parser.add_argument('--color-profile', choices=['linear', 'srgb'], default='srgb',
                                help='Color profile to use (default: srgb)')
    compress_parser.add_argument('--quality', type=int, choices=range(0, 101), default=75,
                                help='Compression quality, 0-100 (default: 75)')
    compress_parser.add_argument('--dimension', choices=['2d', '3d'], default='2d',
                                help='Texture dimension (default: 2d)')
    
    # Decompress command
    decompress_parser = subparsers.add_parser('decompress', help='Decompress an ASTC file to image')
    decompress_parser.add_argument('input', help='Input ASTC file')
    decompress_parser.add_argument('output', help='Output image file (PNG, BMP)')
    decompress_parser.add_argument('--color-profile', choices=['linear', 'srgb'], default='srgb',
                                  help='Color profile to use (default: srgb)')
    
    # Test command
    test_parser = subparsers.add_parser('test', help='Test compression with quality metrics')
    test_parser.add_argument('input', help='Input image file to test compression on')
    test_parser.add_argument('--block-size', default='4x4',
                           help=f'Block size for compression. Options: {", ".join(DEFAULT_BLOCK_SIZES)}')
    test_parser.add_argument('--color-profile', choices=['linear', 'srgb'], default='srgb',
                           help='Color profile to use (default: srgb)')
    test_parser.add_argument('--quality', type=int, choices=range(0, 101), default=75,
                           help='Compression quality, 0-100 (default: 75)')
    test_parser.add_argument('--output', help='Optional output of compressed image for visual comparison')
    
    return parser

def validate_args(args: argparse.Namespace) -> bool:
    """Validate command line arguments"""
    if args.command is None:
        print("Error: You must specify a command. Use --help for more information.")
        return False
    
    if args.command in ['compress', 'test']:
        if not is_valid_block_size(args.block_size):
            print(f"Error: Invalid block size '{args.block_size}'. Valid options: {', '.join(DEFAULT_BLOCK_SIZES)}")
            return False
        
        if not os.path.isfile(args.input):
            print(f"Error: Input file '{args.input}' does not exist.")
            return False
        
        ext = os.path.splitext(args.input)[1].lower()
        if ext not in ['.png', '.bmp']:
            print(f"Error: Input file must be PNG or BMP format, got '{ext}'")
            return False
            
    if args.command == 'decompress':
        if not os.path.isfile(args.input):
            print(f"Error: Input file '{args.input}' does not exist.")
            return False
            
        ext = os.path.splitext(args.input)[1].lower()
        if ext != '.astc':
            print(f"Error: Input file must be ASTC format, got '{ext}'")
            return False
    
    return True

def main(argv: Optional[List[str]] = None) -> int:
    """Main entry point for the CLI"""
    parser = create_parser()
    args = parser.parse_args(argv)
    
    setup_logging(args.verbose)
    
    if not validate_args(args):
        return 1
    
    try:
        if args.command == 'compress':
            logging.info(f"Compressing {args.input} to {args.output} with block size {args.block_size}")
            compress_image(
                args.input, 
                args.output, 
                args.block_size, 
                args.color_profile, 
                args.quality,
                args.dimension
            )
            logging.info("Compression completed successfully")
            
        elif args.command == 'decompress':
            logging.info(f"Decompressing {args.input} to {args.output}")
            decompress_image(
                args.input, 
                args.output, 
                args.color_profile
            )
            logging.info("Decompression completed successfully")
            
        elif args.command == 'test':
            logging.info(f"Testing compression on {args.input} with block size {args.block_size}")
            metrics = compute_metrics(
                args.input, 
                args.block_size, 
                args.color_profile, 
                args.quality,
                args.output
            )
            
            print("\nCompression Quality Metrics:")
            print(f"PSNR: {metrics['psnr']:.2f} dB")
            if 'ssim' in metrics:
                print(f"SSIM: {metrics['ssim']:.4f}")
            print(f"Compression ratio: {metrics['compression_ratio']:.2f}x")
            print(f"File size: Original: {metrics['original_size']/1024:.2f} KB, "
                  f"Compressed: {metrics['compressed_size']/1024:.2f} KB")
            
    except Exception as e:
        logging.error(f"Error: {str(e)}")
        if args.verbose >= 2:
            logging.exception("Detailed traceback:")
        return 1
        
    return 0

if __name__ == '__main__':
    sys.exit(main())
