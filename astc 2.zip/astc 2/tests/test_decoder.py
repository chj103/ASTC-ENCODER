"""
Unit tests for ASTC decoder functions
"""
import os
import pytest
import tempfile
import numpy as np
from PIL import Image

from astc_encoder.encoder import compress_image
from astc_encoder.decoder import decompress_image
from astc_encoder.utils import parse_block_size, is_valid_block_size

# Create a simple test image
def create_test_image(width=64, height=64, mode='RGBA'):
    """Create a test image with a simple pattern"""
    img = Image.new(mode, (width, height), color=(0, 0, 0, 0))
    pixels = img.load()
    
    # Create a simple gradient pattern
    for y in range(height):
        for x in range(width):
            r = int(255 * x / width)
            g = int(255 * y / height)
            b = int(255 * (x + y) / (width + height))
            a = 255
            pixels[x, y] = (r, g, b, a)
    
    return img

def test_round_trip():
    """Test complete compression and decompression round trip"""
    # Create a test image
    test_img = create_test_image(64, 64)
    
    with tempfile.NamedTemporaryFile(suffix='.png') as temp_input:
        with tempfile.NamedTemporaryFile(suffix='.astc') as temp_compressed:
            with tempfile.NamedTemporaryFile(suffix='.png') as temp_output:
                # Save the test image
                test_img.save(temp_input.name)
                
                # Compress the image
                compress_image(
                    temp_input.name,
                    temp_compressed.name,
                    block_size='4x4',
                    color_profile='srgb'
                )
                
                # Decompress the image
                decompress_image(
                    temp_compressed.name,
                    temp_output.name,
                    color_profile='srgb'
                )
                
                # Check if the output file exists and has content
                assert os.path.exists(temp_output.name)
                assert os.path.getsize(temp_output.name) > 0
                
                # Load and check the decompressed image
                decompressed_img = Image.open(temp_output.name)
                assert decompressed_img.size == test_img.size
                assert decompressed_img.mode == test_img.mode

def test_decompression_different_block_sizes():
    """Test decompression with different block sizes"""
    # Create a test image
    test_img = create_test_image(64, 64)
    
    with tempfile.NamedTemporaryFile(suffix='.png') as temp_input:
        test_img.save(temp_input.name)
        
        # Test different block sizes
        block_sizes = ['4x4', '8x8', '12x12']
        
        for block_size in block_sizes:
            with tempfile.NamedTemporaryFile(suffix='.astc') as temp_compressed:
                with tempfile.NamedTemporaryFile(suffix='.png') as temp_output:
                    # Compress the image
                    compress_image(
                        temp_input.name,
                        temp_compressed.name,
                        block_size=block_size,
                        color_profile='srgb'
                    )
                    
                    # Decompress the image
                    decompress_image(
                        temp_compressed.name,
                        temp_output.name,
                        color_profile='srgb'
                    )
                    
                    # Check if the output file exists and has content
                    assert os.path.exists(temp_output.name)
                    assert os.path.getsize(temp_output.name) > 0
                    
                    # Load and check the decompressed image
                    decompressed_img = Image.open(temp_output.name)
                    assert decompressed_img.size == test_img.size

def test_color_profile_conversion():
    """Test compression/decompression with different color profiles"""
    # Create a test image
    test_img = create_test_image(64, 64)
    
    with tempfile.NamedTemporaryFile(suffix='.png') as temp_input:
        test_img.save(temp_input.name)
        
        # Test different color profiles
        color_profiles = ['linear', 'srgb']
        
        for profile in color_profiles:
            with tempfile.NamedTemporaryFile(suffix='.astc') as temp_compressed:
                with tempfile.NamedTemporaryFile(suffix='.png') as temp_output:
                    # Compress the image
                    compress_image(
                        temp_input.name,
                        temp_compressed.name,
                        block_size='4x4',
                        color_profile=profile
                    )
                    
                    # Decompress the image with the same profile
                    decompress_image(
                        temp_compressed.name,
                        temp_output.name,
                        color_profile=profile
                    )
                    
                    # Check if the output file exists and has content
                    assert os.path.exists(temp_output.name)
                    assert os.path.getsize(temp_output.name) > 0
                    
                    # Load and check the decompressed image
                    decompressed_img = Image.open(temp_output.name)
                    assert decompressed_img.size == test_img.size
