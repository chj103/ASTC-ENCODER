"""
Core ASTC encoding and decoding functions.
This module implements the core algorithms for ASTC texture compression.
"""
import numpy as np
import logging
from typing import List, Tuple, Dict, Union, Optional

# Try to import the optimized Cython implementation
try:
    from .optimizations import fast_compress_block, fast_decompress_block
    USE_CYTHON = True
    logging.info("Using optimized Cython implementation")
except ImportError:
    USE_CYTHON = False
    logging.warning("Cython optimizations not available, using pure Python implementation")

# ASTC file format constants
ASTC_MAGIC = b'\x13\xAB\xA1\x5C'  # ASTC magic number

def create_astc_header(width: int, height: int, depth: int, block_dims: List[int]) -> bytes:
    """
    Create an ASTC file header
    
    Args:
        width: Image width in pixels
        height: Image height in pixels
        depth: Image depth in pixels (1 for 2D textures)
        block_dims: Block dimensions [width, height, depth]
    
    Returns:
        bytes: ASTC header data
    """
    header = bytearray()
    
    # Magic number
    header.extend(ASTC_MAGIC)
    
    # Block dimensions (1 byte each)
    header.extend([block_dims[0], block_dims[1], 1 if len(block_dims) < 3 else block_dims[2]])
    
    # Image dimensions (3 bytes each, little endian)
    header.extend([width & 0xFF, (width >> 8) & 0xFF, (width >> 16) & 0xFF])
    header.extend([height & 0xFF, (height >> 8) & 0xFF, (height >> 16) & 0xFF])
    header.extend([depth & 0xFF, (depth >> 8) & 0xFF, (depth >> 16) & 0xFF])
    
    # Total header size is 16 bytes
    return bytes(header)

def parse_astc_header(data: bytes) -> Tuple[int, int, int, int, List[int]]:
    """
    Parse an ASTC file header
    
    Args:
        data: ASTC file data
    
    Returns:
        tuple: (header_size, width, height, depth, block_dims)
    """
    if len(data) < 16:
        raise ValueError("Invalid ASTC file: too small")
    
    # Check magic number
    if data[:4] != ASTC_MAGIC:
        raise ValueError("Invalid ASTC file: incorrect magic number")
    
    # Extract block dimensions
    block_x = data[4]
    block_y = data[5]
    block_z = data[6]
    block_dims = [block_x, block_y]
    if block_z > 1:
        block_dims.append(block_z)
    
    # Extract image dimensions
    width = data[7] | (data[8] << 8) | (data[9] << 16)
    height = data[10] | (data[11] << 8) | (data[12] << 16)
    depth = data[13] | (data[14] << 8) | (data[15] << 16)
    
    header_size = 16
    return header_size, width, height, depth, block_dims

def compress_block(block_data: np.ndarray, block_dims: List[int], error_threshold: float = 0.1) -> bytes:
    """
    Compress an image block to ASTC format
    
    Args:
        block_data: Image block data as numpy array (height, width, 4) for RGBA
        block_dims: Block dimensions [width, height, depth]
        error_threshold: Error threshold for compression quality
        
    Returns:
        bytes: Compressed block data (16 bytes)
    """
    if USE_CYTHON:
        return fast_compress_block(block_data, block_dims, error_threshold)
    
    # Fall back to Python implementation
    return _py_compress_block(block_data, block_dims, error_threshold)

def _py_compress_block(block_data: np.ndarray, block_dims: List[int], error_threshold: float = 0.1) -> bytes:
    """
    Pure Python implementation of ASTC block compression.
    This is a simplified implementation focusing on the basic principles.
    
    Core ASTC compression steps:
    1. Partition the block
    2. Select endpoints for each partition
    3. Quantize and encode endpoints
    4. Assign weights to texels
    5. Pack into the 128-bit ASTC block format
    
    Args:
        block_data: Image block data as numpy array (height, width, 4) for RGBA
        block_dims: Block dimensions [width, height, depth]
        error_threshold: Error threshold for compression quality
        
    Returns:
        bytes: Compressed block data (16 bytes)
    """
    is_3d = len(block_dims) > 2
    
    # Step 1: Determine if this is a solid color block
    is_solid = np.all(block_data == block_data[0, 0])
    
    # Step 2: For a solid color block, use a simpler encoding
    if is_solid:
        color = block_data[0, 0]  # Get the solid color
        return _encode_solid_block(color)
    
    # Step 3: For more complex blocks, use endpoint compression
    # (Simplification: we'll just use a basic endpoint mode with 2 endpoints)
    
    # Find min and max colors in the block
    if is_3d:
        # For 3D blocks, reshape for easier processing
        flat_data = block_data.reshape(-1, 4)  # RGBA
    else:
        flat_data = block_data.reshape(-1, 4)  # RGBA
    
    # Use PCA to find the primary color axis
    # Simplification: just use min/max in each channel
    min_color = np.min(flat_data, axis=0)
    max_color = np.max(flat_data, axis=0)
    
    # Adjust endpoints to improve quality
    endpoint1 = min_color.astype(np.uint8)
    endpoint2 = max_color.astype(np.uint8)
    
    # Step 4: Create weight grid
    weights = _calculate_weights(block_data, endpoint1, endpoint2)
    
    # Step 5: Encode block
    result = _encode_endpoint_block(endpoint1, endpoint2, weights, block_dims)
    
    return result

def _encode_solid_block(color: np.ndarray) -> bytes:
    """
    Encode a solid color block in ASTC format
    
    Args:
        color: RGBA color as numpy array
        
    Returns:
        bytes: Compressed block data (16 bytes)
    """
    # For solid blocks, ASTC uses a void-extent block with single color
    # This is a simplified implementation
    
    # Convert 8-bit color to ASTC format (simplified)
    r, g, b, a = color
    
    # Create 128-bit block (all zeroes initially)
    block = bytearray(16)
    
    # Set the block mode for solid color (mode 0)
    block[0] = 0xFC
    
    # Store color values in specific bit positions - convert any floats to ints
    # (This is simplified; real ASTC uses more complex encoding)
    block[1] = int(r)
    block[2] = int(g)
    block[3] = int(b)
    block[4] = int(a)
    
    return bytes(block)

def _calculate_weights(block_data: np.ndarray, endpoint1: np.ndarray, endpoint2: np.ndarray) -> np.ndarray:
    """
    Calculate interpolation weights for each texel
    
    Args:
        block_data: Image block data
        endpoint1: First color endpoint
        endpoint2: Second color endpoint
        
    Returns:
        np.ndarray: Weight grid
    """
    # Convert endpoints to float for calculations
    e1 = endpoint1.astype(np.float32)
    e2 = endpoint2.astype(np.float32)
    
    # Calculate the direction vector
    dir_vec = e2 - e1
    dir_vec_length_squared = np.sum(dir_vec**2)
    
    # Avoid division by zero
    if dir_vec_length_squared < 1e-6:
        return np.zeros(block_data.shape[:2], dtype=np.uint8)
    
    # Calculate weights as projection onto direction vector
    weights = np.zeros(block_data.shape[:2], dtype=np.uint8)
    for y in range(block_data.shape[0]):
        for x in range(block_data.shape[1]):
            color = block_data[y, x].astype(np.float32)
            # Project color onto direction vector
            t = np.sum((color - e1) * dir_vec) / dir_vec_length_squared
            # Clamp and quantize to 8-bit weight
            t = np.clip(t, 0, 1)
            weights[y, x] = int(t * 255)
    
    return weights

def _encode_endpoint_block(endpoint1: np.ndarray, endpoint2: np.ndarray, 
                          weights: np.ndarray, block_dims: List[int]) -> bytes:
    """
    Encode an endpoint-mode block in ASTC format
    
    Args:
        endpoint1: First color endpoint
        endpoint2: Second color endpoint
        weights: Weight grid
        block_dims: Block dimensions
        
    Returns:
        bytes: Compressed block data (16 bytes)
    """
    # This is a simplified encoding that doesn't implement all ASTC features
    # Real ASTC uses a complex bit arrangement to fit color endpoints and weights
    
    # Create 128-bit block
    block = bytearray(16)
    
    # Set the block mode for endpoint encoding
    # Mode 6: dual-plane, 8 partitions, 4-texel weight grid
    block[0] = 0x02
    
    # Simplified: just store the endpoints and some weight values
    block[1] = int(endpoint1[0])  # R1
    block[2] = int(endpoint1[1])  # G1
    block[3] = int(endpoint1[2])  # B1
    block[4] = int(endpoint1[3])  # A1
    
    block[5] = int(endpoint2[0])  # R2
    block[6] = int(endpoint2[1])  # G2
    block[7] = int(endpoint2[2])  # B2
    block[8] = int(endpoint2[3])  # A2
    
    # Store a few weight values (simplified)
    # In real ASTC, weights are encoded more efficiently
    for i in range(min(7, weights.size)):
        idx = i // weights.shape[1]
        idy = i % weights.shape[1]
        block[9 + i] = int(weights[idx, idy])
    
    return bytes(block)

def decompress_block(block_data: bytes, block_dims: List[int]) -> np.ndarray:
    """
    Decompress an ASTC block to image data
    
    Args:
        block_data: Compressed block data (16 bytes)
        block_dims: Block dimensions [width, height, depth]
        
    Returns:
        np.ndarray: Decompressed block data
    """
    if USE_CYTHON:
        return fast_decompress_block(block_data, block_dims)
    
    # Fall back to Python implementation
    return _py_decompress_block(block_data, block_dims)

def _py_decompress_block(block_data: bytes, block_dims: List[int]) -> np.ndarray:
    """
    Pure Python implementation of ASTC block decompression
    
    Args:
        block_data: Compressed block data (16 bytes)
        block_dims: Block dimensions [width, height, depth]
        
    Returns:
        np.ndarray: Decompressed block data
    """
    if len(block_data) != 16:
        raise ValueError(f"Invalid block size: {len(block_data)} bytes (expected 16)")
    
    # Determine block mode
    block_mode = block_data[0]
    
    # Check if this is a solid color block (simplified detection)
    if block_mode >= 0xFC:
        # Extract the single color (convert bytes to integers)
        r = block_data[1]
        g = block_data[2]
        b = block_data[3]
        a = block_data[4]
        color = np.array([r, g, b, a], dtype=np.uint8)
        
        # Create a block filled with this color
        if len(block_dims) > 2:
            # 3D block
            block = np.zeros((block_dims[1], block_dims[0], block_dims[2], 4), dtype=np.uint8)
            block[:, :, :] = color
        else:
            # 2D block
            block = np.zeros((block_dims[1], block_dims[0], 4), dtype=np.uint8)
            block[:, :] = color
            
        return block
    
    # Otherwise, this is an endpoint mode block
    # Extract endpoints (simplified) - convert bytes to integers
    endpoint1 = np.array([block_data[1], block_data[2], block_data[3], block_data[4]], dtype=np.uint8)
    endpoint2 = np.array([block_data[5], block_data[6], block_data[7], block_data[8]], dtype=np.uint8)
    
    # Extract weights (simplified)
    weights = np.zeros((block_dims[1], block_dims[0]), dtype=np.float32)
    for y in range(min(block_dims[1], 4)):
        for x in range(min(block_dims[0], 4)):
            idx = y * block_dims[0] + x
            if idx < 7:  # We stored only a few weights
                weights[y, x] = block_data[9 + idx] / 255.0
            else:
                # For missing weights, use a simple pattern
                weights[y, x] = 0.5
    
    # Interpolate colors using weights
    if len(block_dims) > 2:
        # 3D block
        block = np.zeros((block_dims[1], block_dims[0], block_dims[2], 4), dtype=np.uint8)
        for z in range(block_dims[2]):
            for y in range(block_dims[1]):
                for x in range(block_dims[0]):
                    weight = weights[min(y, weights.shape[0]-1), min(x, weights.shape[1]-1)]
                    color = (1 - weight) * endpoint1 + weight * endpoint2
                    block[y, x, z] = color.astype(np.uint8)
    else:
        # 2D block
        block = np.zeros((block_dims[1], block_dims[0], 4), dtype=np.uint8)
        for y in range(block_dims[1]):
            for x in range(block_dims[0]):
                weight = weights[min(y, weights.shape[0]-1), min(x, weights.shape[1]-1)]
                color = (1 - weight) * endpoint1 + weight * endpoint2
                block[y, x] = color.astype(np.uint8)
    
    return block
