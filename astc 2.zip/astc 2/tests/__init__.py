"""
Test package for ASTC encoder
"""
